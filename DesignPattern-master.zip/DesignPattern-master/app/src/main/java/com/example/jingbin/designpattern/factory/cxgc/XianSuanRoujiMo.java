package com.example.jingbin.designpattern.factory.cxgc;


/**
 * Created by jingbin on 2016/10/25.
 */

public class XianSuanRoujiMo extends RoujiaMo {

    public XianSuanRoujiMo() {
        this.name = "西安 酸肉夹馍";
    }
}
