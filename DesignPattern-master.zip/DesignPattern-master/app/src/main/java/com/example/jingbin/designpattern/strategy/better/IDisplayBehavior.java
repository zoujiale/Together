package com.example.jingbin.designpattern.strategy.better;

/**
 * Created by jingbin on 2016/10/30.
 */

public interface IDisplayBehavior {
    void display();
}
