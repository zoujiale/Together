package com.example.jingbin.designpattern.factory.cxgc;

/**
 * Created by jingbin on 2016/10/26.
 */

public class XianFreshMeet extends Meet {
    public String meet = "西安鲜肉";
}
