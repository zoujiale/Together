package com.example.jingbin.designpattern.factory.cxgc;

/**
 * Created by jingbin on 2016/10/26.
 */

public class ChangShaFreshMeet extends Meet {

    public String meet = "长沙鲜肉";
}
