package com.example.jingbin.designpattern.factory.jdgc;

/**
 * Created by jingbin on 2016/10/22.
 */

public class ZLaRoujiaMo extends RoujiaMo {

    public ZLaRoujiaMo(){
        this.name = "辣味肉夹馍";
    }
}
