package com.example.jingbin.designpattern.factory.gcff;

import com.example.jingbin.designpattern.factory.jdgc.RoujiaMo;

/**
 * Created by jingbin on 2016/10/25.
 */

public class XianKuRoujiMo extends RoujiaMo {

    public XianKuRoujiMo() {
        this.name = "西安 苦肉夹馍";
    }
}
